/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Services } from './components/Services';
import { Portfolio } from './components/Portfolio';
import { SocialSection } from './components/SocialSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { EditProfileModal } from './components/EditProfileModal';
import { ChangePhotoModal } from './components/ChangePhotoModal';
import { DEFAULT_PROFILE, CONSULTING_SERVICES, PORTFOLIO_PROJECTS } from './data/defaultData';
import { ProfileData } from './types';

export default function App() {
  const [profile, setProfile] = useState<ProfileData>(() => {
    try {
      const saved = localStorage.getItem('basant_profile_data');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (err) {
      console.warn('Error reading stored profile, falling back to default:', err);
    }
    return DEFAULT_PROFILE;
  });

  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isChangePhotoModalOpen, setIsChangePhotoModalOpen] = useState(false);

  // Sync title and metadata if profile name changes
  useEffect(() => {
    document.title = `${profile.name} | Official Personal Website`;
  }, [profile.name]);

  const handleSaveProfile = (updatedProfile: ProfileData) => {
    setProfile(updatedProfile);
    try {
      localStorage.setItem('basant_profile_data', JSON.stringify(updatedProfile));
    } catch (err) {
      console.error('Failed to persist profile to localStorage:', err);
    }
  };

  const handleResetProfile = () => {
    setProfile(DEFAULT_PROFILE);
    try {
      localStorage.removeItem('basant_profile_data');
    } catch (err) {
      console.error('Failed to reset profile:', err);
    }
  };

  const handleSavePhoto = (newPhotoUrl: string) => {
    const updated = { ...profile, avatarUrl: newPhotoUrl };
    handleSaveProfile(updated);
  };

  return (
    <div className="min-h-screen bg-[#09090b] text-[#f4f4f5] flex flex-col font-sans-luxury selection:bg-amber-400/25 selection:text-white">
      {/* Top Navigation */}
      <Navbar
        onOpenEditModal={() => setIsEditModalOpen(true)}
        whatsappUrl={profile.whatsappUrl}
      />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* Hero Section */}
        <Hero
          profile={profile}
          onChangePhotoClick={() => setIsChangePhotoModalOpen(true)}
        />

        {/* About Me Section */}
        <About
          profile={profile}
          onOpenEditModal={() => setIsEditModalOpen(true)}
        />

        {/* Consulting Services Section */}
        <Services
          services={CONSULTING_SERVICES}
          whatsappUrl={profile.whatsappUrl}
        />

        {/* Portfolio & Case Studies Section */}
        <Portfolio
          projects={PORTFOLIO_PROJECTS}
          whatsappUrl={profile.whatsappUrl}
        />

        {/* Social Media Section */}
        <SocialSection
          profile={profile}
        />

        {/* Contact Section */}
        <ContactSection
          profile={profile}
        />
      </main>

      {/* Official Footer */}
      <Footer profile={profile} />

      {/* Profile Information Customizer Modal */}
      {isEditModalOpen && (
        <EditProfileModal
          profile={profile}
          onSave={handleSaveProfile}
          onReset={handleResetProfile}
          onClose={() => setIsEditModalOpen(false)}
        />
      )}

      {/* Profile Photo Customizer Modal */}
      {isChangePhotoModalOpen && (
        <ChangePhotoModal
          currentPhotoUrl={profile.avatarUrl}
          defaultPhotoUrl={DEFAULT_PROFILE.avatarUrl}
          onSave={handleSavePhoto}
          onClose={() => setIsChangePhotoModalOpen(false)}
        />
      )}
    </div>
  );
}
