import { ProfileData, ConsultingService, PortfolioItem } from '../types';

export const DEFAULT_PROFILE: ProfileData = {
  name: 'Basant Bajpai',
  tagline: 'Welcome to My World — Creating My Own Identity.',
  heroIntro:
    "Hi, I'm Basant Bajpai. Welcome to my personal website, where you can discover more about me, connect with me, and follow my journey.",
  aboutIntro:
    "I am an entrepreneur and independent consultant committed to forging high-impact business strategies and cultivating distinct personal & brand identities. Driven by purpose and disciplined execution, I collaborate with founders, professionals, and emerging enterprises to solve strategic bottlenecks and create enduring market value.",
  location: 'India',
  email: 'basantbajpai44@gmail.com',
  phone: '+91 6232322853',
  whatsappNumber: '+91 6232322853',
  whatsappUrl: 'https://wa.me/916232322853',
  instagramUrl: 'https://www.instagram.com/basant_.bajpai?xtok=MmMyYmk2d2Ywa2h1',
  instagramHandle: '@basant_.bajpai',
  avatarUrl: '/src/assets/images/basant_bajpai_portrait_1792048244481.jpg',
  interests: [
    'Business Strategy & Advisory',
    'Personal Identity & Executive Brand Building',
    'Market Positioning & High-Value Deals',
    'Creative Direction & Modern Storytelling',
    'Tech Enablement & Workflow Automation'
  ],
  goals: [
    'Expand independent consulting advisory across high-growth ventures',
    'Empower aspiring founders to define unique, authentic brand identities',
    'Build sustainable business relationships rooted in mutual integrity',
    'Continually elevate leadership capabilities and strategic frameworks'
  ],
  hobbies: [
    'Reading strategic literature and leadership biographies',
    'Fitness and disciplined daily strength training',
    'Exploring new cities, culture, and architecture',
    'Networking with forward-thinking professionals and creators'
  ],
  achievements: [
    'Founded independent consulting practice focused on strategy & brand positioning',
    'Successfully advised emerging entrepreneurs on market entry and outreach',
    'Maintained continuous personal brand presence across social platforms',
    'Established direct client partnerships across diverse service industries'
  ]
};

export const CONSULTING_SERVICES: ConsultingService[] = [
  {
    id: 'strategy',
    title: 'Strategic Business Advisory',
    shortDesc: 'Clarity on direction, target market viability, and scalable business models.',
    fullDesc:
      'Providing founders and executives with objective, analytical perspectives on business positioning, resource allocation, and market differentiation.',
    features: [
      'Strategic diagnostic & operational evaluation',
      'Actionable go-to-market roadmaps',
      'Value proposition calibration',
      'Milestone-driven quarterly execution plans'
    ],
    icon: 'strategy'
  },
  {
    id: 'brand',
    title: 'Brand & Identity Architecture',
    shortDesc: 'Crafting unmistakable personal and corporate identity that commands attention.',
    fullDesc:
      'Translating authentic vision into compelling visual and verbal identity systems that cultivate instant credibility and premium positioning.',
    features: [
      'Personal identity narrative & vision alignment',
      'Executive social presence guidelines',
      'Distinctive tone-of-voice & value messaging',
      'Premium brand presentation frameworks'
    ],
    icon: 'brand'
  },
  {
    id: 'growth',
    title: 'Client Engagement & Growth',
    shortDesc: 'Structured client outreach, relationship stewardship, and deal conversion.',
    fullDesc:
      'Developing sustainable client acquisition pipelines that prioritize trust, transparency, and high lifetime partner satisfaction.',
    features: [
      'Target client profiling & high-touch outreach',
      'Consultative negotiation & proposal structuring',
      'Client retention & relationship workflows',
      'Partnership expansion playbooks'
    ],
    icon: 'growth'
  },
  {
    id: 'operations',
    title: 'Execution & Workflow Optimization',
    shortDesc: 'Bridging high-level strategy with lean daily execution and disciplined follow-through.',
    fullDesc:
      'Eliminating procedural friction, structuring priorities, and establishing accountability systems for sustained momentum.',
    features: [
      'Personal productivity & executive cadence',
      'Lean communication & project management',
      'Delegation frameworks for leaders',
      'Quality control & performance tracking'
    ],
    icon: 'operations'
  }
];

export const PORTFOLIO_PROJECTS: PortfolioItem[] = [
  {
    id: 'executive-identity',
    title: 'Strategic Brand Identity & Market Positioning',
    category: 'Branding',
    year: '2025–2026',
    clientType: 'Private Client Advisory',
    summary:
      'Comprehensive personal branding overhaul for an executive consultant seeking premium positioning in the corporate sector.',
    challenge:
      'Fragmented personal narrative across digital channels resulting in inconsistent client acquisition and commoditized pricing.',
    solution:
      'Engineered an authoritative identity architecture, cohesive digital monograph, refined messaging pillars, and targeted outreach strategy.',
    impact: [
      'Established distinctive high-tier market presence',
      'Streamlined inbound inquiries with qualified decision-makers',
      'Enhanced client close rate through clear value articulation'
    ],
    imageUrl: '/src/assets/images/brand_identity_showcase_1792048245933.jpg'
  },
  {
    id: 'growth-advisory',
    title: 'Enterprise Strategy & Strategic Alignment',
    category: 'Strategy',
    year: '2025–2026',
    clientType: 'Corporate Advisory',
    summary:
      'Facilitated high-stakes executive strategy sessions aligning corporate leadership around expansion priorities and client delivery.',
    challenge:
      'Misaligned divisional goals and sluggish decision-making impacting quarterly milestone delivery.',
    solution:
      'Instituted a streamlined strategic diagnostic, executive cadence framework, and clear KPIs for cross-functional execution.',
    impact: [
      'Reduced decision cycle times across key initiatives',
      'Unified executive leadership around core strategic roadmap',
      'Enhanced partner accountability across operational milestones'
    ],
    imageUrl: '/src/assets/images/consulting_strategy_showcase_1792048246035.jpg'
  },
  {
    id: 'client-outreach',
    title: 'Direct Client Acquisition Architecture',
    category: 'Growth',
    year: '2025',
    clientType: 'Emerging Practice',
    summary:
      'Designed and executed a modern, relationship-first outreach system leveraging direct channels (WhatsApp, executive referrals, and digital presence).',
    challenge:
      'Reliance on informal word-of-mouth without a reliable, consistent channel for new client dialogues.',
    solution:
      'Structured high-touch conversational workflows, clear service packages, and direct messaging engagement scripts.',
    impact: [
      'Created consistent weekly pipeline of high-intent inquiries',
      'Shortened lead-to-consultation response turnaround time',
      'Built direct, personal stakeholder relationships'
    ],
    imageUrl: '/src/assets/images/brand_identity_showcase_1792048245933.jpg'
  }
];
