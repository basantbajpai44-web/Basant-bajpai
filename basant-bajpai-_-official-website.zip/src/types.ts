export interface ProfileData {
  name: string;
  tagline: string;
  heroIntro: string;
  aboutIntro: string;
  location: string;
  email: string;
  phone: string;
  whatsappNumber: string;
  whatsappUrl: string;
  instagramUrl: string;
  instagramHandle: string;
  avatarUrl: string;
  interests: string[];
  goals: string[];
  hobbies: string[];
  achievements: string[];
}

export interface ConsultingService {
  id: string;
  title: string;
  shortDesc: string;
  fullDesc: string;
  features: string[];
  icon: 'strategy' | 'brand' | 'growth' | 'operations';
}

export interface PortfolioItem {
  id: string;
  title: string;
  category: 'Strategy' | 'Branding' | 'Growth';
  year: string;
  clientType: string;
  summary: string;
  challenge: string;
  solution: string;
  impact: string[];
  imageUrl: string;
}
