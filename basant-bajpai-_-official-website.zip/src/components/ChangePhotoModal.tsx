import React, { useState } from 'react';
import { X, Upload, Link, Check, RefreshCw } from 'lucide-react';

interface ChangePhotoModalProps {
  currentPhotoUrl: string;
  defaultPhotoUrl: string;
  onSave: (newUrl: string) => void;
  onClose: () => void;
}

export const ChangePhotoModal: React.FC<ChangePhotoModalProps> = ({
  currentPhotoUrl,
  defaultPhotoUrl,
  onSave,
  onClose,
}) => {
  const [photoUrl, setPhotoUrl] = useState(currentPhotoUrl);
  const [activeTab, setActiveTab] = useState<'upload' | 'url'>('upload');
  const [errorMsg, setErrorMsg] = useState('');

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrorMsg('Please select a valid image file (JPG, PNG, WebP).');
      return;
    }

    if (file.size > 8 * 1024 * 1024) {
      setErrorMsg('Image size should be under 8MB.');
      return;
    }

    setErrorMsg('');
    const reader = new FileReader();
    reader.onload = (event) => {
      if (typeof event.target?.result === 'string') {
        setPhotoUrl(event.target.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSave = () => {
    if (!photoUrl.trim()) {
      setErrorMsg('Please provide or upload a photo.');
      return;
    }
    onSave(photoUrl);
    onClose();
  };

  const handleResetToDefault = () => {
    setPhotoUrl(defaultPhotoUrl);
    setErrorMsg('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-zinc-950 border border-zinc-800 rounded-2xl max-w-lg w-full p-6 sm:p-8 relative shadow-2xl">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-lg bg-zinc-900 text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          aria-label="Close dialog"
        >
          <X className="w-5 h-5" />
        </button>

        <h3 className="text-xl font-bold font-serif-luxury text-white mb-1">
          Update Profile Photograph
        </h3>
        <p className="text-xs text-zinc-400 mb-6">
          Replace the default photo with your own personal headshot or photograph.
        </p>

        {/* Circular Live Preview */}
        <div className="flex flex-col items-center justify-center mb-6">
          <div className="relative w-36 h-36 rounded-full overflow-hidden border-4 border-amber-400/50 shadow-lg shadow-black bg-zinc-900">
            <img
              src={photoUrl}
              alt="Preview"
              className="w-full h-full object-cover"
              onError={() => setErrorMsg('Unable to load image. Check the URL.')}
            />
          </div>
          <span className="text-[11px] text-zinc-500 mt-2">Live circular frame preview</span>
        </div>

        {/* Tab selection */}
        <div className="flex items-center gap-2 p-1 bg-zinc-900 border border-zinc-800 rounded-xl mb-4">
          <button
            type="button"
            onClick={() => setActiveTab('upload')}
            className={`flex-1 py-2 text-xs font-semibold rounded-lg flex items-center justify-center gap-2 transition-colors ${
              activeTab === 'upload' ? 'bg-amber-400 text-black' : 'text-zinc-400 hover:text-white'
            }`}
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Upload From Device</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('url')}
            className={`flex-1 py-2 text-xs font-semibold rounded-lg flex items-center justify-center gap-2 transition-colors ${
              activeTab === 'url' ? 'bg-amber-400 text-black' : 'text-zinc-400 hover:text-white'
            }`}
          >
            <Link className="w-3.5 h-3.5" />
            <span>Image URL Link</span>
          </button>
        </div>

        {/* Tab Content */}
        {activeTab === 'upload' ? (
          <div className="mb-6">
            <label className="block border-2 border-dashed border-zinc-800 hover:border-amber-400/50 rounded-xl p-6 text-center cursor-pointer transition-colors bg-zinc-900/50">
              <Upload className="w-8 h-8 text-amber-400 mx-auto mb-2" />
              <span className="text-xs font-medium text-zinc-200 block mb-1">
                Click to browse photo from phone or computer
              </span>
              <span className="text-[11px] text-zinc-500 block">
                Supports JPG, PNG, WEBP (Max 8MB)
              </span>
              <input
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>
          </div>
        ) : (
          <div className="mb-6">
            <label className="block text-xs font-medium text-zinc-300 mb-1.5 uppercase tracking-wider">
              Paste Image URL
            </label>
            <input
              type="url"
              value={photoUrl}
              onChange={(e) => {
                setPhotoUrl(e.target.value);
                setErrorMsg('');
              }}
              placeholder="https://..."
              className="w-full px-4 py-2.5 bg-zinc-900 border border-zinc-800 rounded-xl text-white placeholder-zinc-500 focus:outline-none focus:border-amber-400 text-sm"
            />
          </div>
        )}

        {errorMsg && (
          <p className="text-xs text-rose-400 mb-4">{errorMsg}</p>
        )}

        {/* Modal Actions */}
        <div className="flex items-center justify-between gap-3 pt-4 border-t border-zinc-800/80">
          <button
            type="button"
            onClick={handleResetToDefault}
            className="inline-flex items-center gap-1.5 text-xs text-zinc-400 hover:text-amber-400 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Reset Default</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-zinc-300 hover:text-white bg-zinc-900 hover:bg-zinc-800 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-bold uppercase tracking-wider text-black bg-gradient-to-r from-amber-300 to-amber-500 rounded-lg hover:from-amber-200 hover:to-amber-400 transition-colors"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Apply Photo</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
