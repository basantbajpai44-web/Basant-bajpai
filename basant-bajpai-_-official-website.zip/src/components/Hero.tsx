import React from 'react';
import { Camera, Instagram, ArrowRight, Sparkles, CheckCircle2 } from 'lucide-react';
import { ProfileData } from '../types';

interface HeroProps {
  profile: ProfileData;
  onChangePhotoClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({ profile, onChangePhotoClick }) => {
  return (
    <section className="relative min-h-[calc(100vh-5rem)] flex items-center justify-center py-16 lg:py-24 overflow-hidden border-b border-zinc-800/60">
      {/* Ambient luxury subtle golden radial backdrop */}
      <div
        className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[650px] h-[650px] bg-amber-500/5 rounded-full blur-[130px] pointer-events-none"
        aria-hidden="true"
      />
      <div
        className="absolute top-1/2 right-10 w-[400px] h-[400px] bg-amber-600/5 rounded-full blur-[100px] pointer-events-none"
        aria-hidden="true"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Left Column: Typographic & Brand Identity */}
          <div className="lg:col-span-7 flex flex-col justify-center text-center lg:text-left order-2 lg:order-1">
            
            {/* Subtle luxury editorial badge */}
            <div className="inline-flex items-center gap-2 self-center lg:self-start text-xs font-semibold tracking-[0.25em] uppercase text-amber-400/90 mb-4 px-3.5 py-1 rounded-full bg-amber-400/10 border border-amber-400/20 backdrop-blur-sm">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Independent Consultant & Entrepreneur</span>
            </div>

            {/* Prominent Name */}
            <h1 className="font-serif-luxury text-4xl sm:text-6xl xl:text-7xl font-bold tracking-tight text-white mb-4 uppercase">
              <span className="block drop-shadow-sm">{profile.name}</span>
            </h1>

            {/* Exact Tagline requested */}
            <div className="relative mb-6">
              <p className="text-lg sm:text-xl md:text-2xl font-medium tracking-wide text-amber-300 font-sans-luxury">
                "{profile.tagline}"
              </p>
              <div className="w-16 h-0.5 bg-gradient-to-r from-amber-400 to-transparent mt-3 mx-auto lg:mx-0" />
            </div>

            {/* Exact Short Introduction requested */}
            <p className="text-zinc-300 text-base sm:text-lg leading-relaxed max-w-2xl mb-8 mx-auto lg:mx-0 font-normal">
              {profile.heroIntro}
            </p>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 sm:gap-5">
              {/* Button 1: Connect With Me */}
              <a
                href="#contact"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-3.5 text-sm font-semibold uppercase tracking-wider text-black bg-gradient-to-r from-amber-300 via-amber-400 to-amber-500 rounded-xl hover:from-amber-200 hover:to-amber-400 transition-all duration-300 shadow-lg shadow-amber-500/15 hover:shadow-amber-500/25 group"
              >
                <span>Connect With Me</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </a>

              {/* Button 2: Follow on Instagram */}
              <a
                href={profile.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-7 py-3.5 text-sm font-medium text-white bg-zinc-900/90 hover:bg-zinc-800 border border-zinc-700/80 hover:border-amber-400/50 rounded-xl transition-all duration-300 group"
              >
                <Instagram className="w-4 h-4 text-pink-400 group-hover:text-amber-300 transition-colors" />
                <span>Follow on Instagram</span>
              </a>
            </div>

            {/* Trust Markers & Credibility Strip (clean unboxed text with separators) */}
            <div className="mt-10 pt-6 border-t border-zinc-800/70 flex flex-wrap items-center justify-center lg:justify-start gap-y-2 gap-x-4 text-xs font-medium text-zinc-400">
              <span className="flex items-center gap-1.5 text-zinc-300">
                <CheckCircle2 className="w-4 h-4 text-amber-400" />
                Strategic Advisory
              </span>
              <span aria-hidden="true" className="text-zinc-600">·</span>
              <span className="flex items-center gap-1.5 text-zinc-300">
                <CheckCircle2 className="w-4 h-4 text-amber-400" />
                Identity Architecture
              </span>
              <span aria-hidden="true" className="text-zinc-600">·</span>
              <span className="flex items-center gap-1.5 text-zinc-300">
                <CheckCircle2 className="w-4 h-4 text-amber-400" />
                Direct WhatsApp Availability
              </span>
            </div>

          </div>

          {/* Right Column: Stylish Profile Photo with Circular Frame & Subtle Animation */}
          <div className="lg:col-span-5 flex flex-col items-center justify-center order-1 lg:order-2">
            <div className="relative group">
              
              {/* Outer Golden Concentric Glow Ring */}
              <div className="absolute -inset-2 sm:-inset-3 rounded-full bg-gradient-to-tr from-amber-500/20 via-amber-400/30 to-amber-600/10 blur-md opacity-75 group-hover:opacity-100 transition duration-700 animate-pulse" />
              
              {/* Decorative Rotating Border Accent */}
              <div className="absolute -inset-1 rounded-full p-[2px] bg-gradient-to-r from-amber-400/40 via-yellow-200/20 to-amber-500/40" />

              {/* Circular Avatar Container */}
              <div className="relative w-64 h-64 sm:w-80 sm:h-80 md:w-88 md:h-88 rounded-full overflow-hidden bg-zinc-950 border-4 border-zinc-800 shadow-2xl shadow-black/80 flex items-center justify-center">
                <img
                  src={profile.avatarUrl}
                  alt={`${profile.name} - Official Portrait`}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-top transition duration-500 group-hover:scale-105"
                  onError={(e) => {
                    // Fallback to stylized monogram if file is missing
                    const target = e.currentTarget;
                    target.style.display = 'none';
                    if (target.parentElement) {
                      target.parentElement.innerHTML = `
                        <div class="flex flex-col items-center justify-center text-center p-6 bg-gradient-to-b from-zinc-900 to-zinc-950 w-full h-full">
                          <span class="font-serif-luxury text-5xl font-bold text-amber-400">BB</span>
                          <span class="mt-2 text-xs uppercase tracking-widest text-zinc-400">Basant Bajpai</span>
                        </div>
                      `;
                    }
                  }}
                />

                {/* Hover overlay to easily replace photograph */}
                <button
                  type="button"
                  onClick={onChangePhotoClick}
                  className="absolute inset-0 bg-black/60 backdrop-blur-xs flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200 cursor-pointer text-white"
                  aria-label="Replace profile photograph"
                  title="Upload or change your photo"
                >
                  <div className="p-3 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/40 mb-2">
                    <Camera className="w-5 h-5" />
                  </div>
                  <span className="text-xs font-semibold uppercase tracking-wider text-amber-200">
                    Replace Photo
                  </span>
                  <span className="text-[11px] text-zinc-400 mt-0.5">Click to upload custom picture</span>
                </button>
              </div>

              {/* Bottom Quick Action Badge */}
              <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-1.5 px-4 py-1.5 bg-zinc-900/95 border border-amber-400/40 rounded-full shadow-lg backdrop-blur-md">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-xs font-medium text-zinc-200 whitespace-nowrap">
                  Open for Advisory
                </span>
                <button
                  onClick={onChangePhotoClick}
                  className="ml-1 text-[11px] text-amber-400 hover:text-amber-300 underline underline-offset-2"
                >
                  Edit Photo
                </button>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
