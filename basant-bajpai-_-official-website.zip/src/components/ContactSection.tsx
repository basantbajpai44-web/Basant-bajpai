import React, { useState } from 'react';
import { MessageCircle, Instagram, Send, CheckCircle2, ArrowRight } from 'lucide-react';
import { ProfileData } from '../types';

interface ContactSectionProps {
  profile: ProfileData;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ profile }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: 'Consulting Advisory',
    message: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) return;

    setIsSubmitting(true);

    // Save message locally for persistence
    const existingMessages = JSON.parse(localStorage.getItem('basant_messages') || '[]');
    const newMessage = {
      ...formData,
      id: Date.now(),
      date: new Date().toISOString(),
    };
    localStorage.setItem('basant_messages', JSON.stringify([newMessage, ...existingMessages]));

    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
    }, 600);
  };

  const openWhatsAppWithMessage = () => {
    const text = `Hi Basant,\n\nName: ${formData.name}\nEmail: ${formData.email}\nTopic: ${formData.subject}\n\nMessage: ${formData.message}`;
    window.open(`${profile.whatsappUrl}?text=${encodeURIComponent(text)}`, '_blank');
  };

  const openEmailWithMessage = () => {
    const body = `Hi Basant,\n\n${formData.message}\n\nFrom: ${formData.name} (${formData.email})`;
    window.location.href = `mailto:${profile.email}?subject=${encodeURIComponent(formData.subject || 'Consulting Inquiry')}&body=${encodeURIComponent(body)}`;
  };

  return (
    <section id="contact" className="py-20 lg:py-28 relative bg-[#09090b]">
      {/* Decorative radial blur */}
      <div
        className="absolute top-1/3 right-1/4 w-[500px] h-[500px] bg-amber-500/5 rounded-full blur-[140px] pointer-events-none"
        aria-hidden="true"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-semibold uppercase tracking-[0.2em] text-amber-400">
            Start A Conversation
          </span>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-bold text-white mt-2 mb-4">
            Get In Touch
          </h2>
          <p className="text-zinc-400 text-base sm:text-lg">
            Whether you want to explore consulting collaboration, discuss strategic advisory, or simply say hello, I'm readily reachable.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Column: Direct Action Buttons (WhatsApp & Instagram) & Info */}
          <div className="lg:col-span-5 space-y-6">
            
            <div className="bg-zinc-950/90 border border-zinc-800 rounded-2xl p-6 sm:p-8 space-y-6">
              <h3 className="text-xl font-bold text-white mb-2">
                Fastest Direct Channels
              </h3>
              <p className="text-zinc-400 text-sm leading-relaxed">
                For prompt replies, message me directly on WhatsApp or connect with me through my verified Instagram profile.
              </p>

              {/* Required Button 1: Message Me on WhatsApp */}
              <a
                href={profile.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full inline-flex items-center justify-between px-6 py-4 rounded-xl bg-emerald-600/15 border border-emerald-500/40 text-emerald-300 hover:bg-emerald-600 hover:text-white transition-all duration-300 group shadow-lg shadow-emerald-950/30"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-emerald-500/20 flex items-center justify-center text-emerald-400 group-hover:bg-white/20 group-hover:text-white transition-colors">
                    <MessageCircle className="w-5 h-5" />
                  </div>
                  <div className="text-left">
                    <div className="text-xs text-emerald-400/80 group-hover:text-emerald-100 uppercase tracking-wider font-semibold">
                      WhatsApp Quick Chat
                    </div>
                    <div className="text-sm font-bold text-white">
                      Message Me on WhatsApp
                    </div>
                  </div>
                </div>
                <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
              </a>

              {/* Required Button 2: Follow Me on Instagram */}
              <a
                href={profile.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full inline-flex items-center justify-between px-6 py-4 rounded-xl bg-pink-600/10 border border-pink-500/30 text-pink-300 hover:bg-gradient-to-r hover:from-pink-600 hover:to-purple-600 hover:text-white hover:border-transparent transition-all duration-300 group shadow-lg shadow-pink-950/20"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-pink-500/20 flex items-center justify-center text-pink-400 group-hover:bg-white/20 group-hover:text-white transition-colors">
                    <Instagram className="w-5 h-5" />
                  </div>
                  <div className="text-left">
                    <div className="text-xs text-pink-400/80 group-hover:text-pink-100 uppercase tracking-wider font-semibold">
                      Instagram Profile
                    </div>
                    <div className="text-sm font-bold text-white">
                      Follow Me on Instagram
                    </div>
                  </div>
                </div>
                <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
              </a>

              <div className="pt-4 border-t border-zinc-900 text-xs text-zinc-400 space-y-2">
                <div className="flex items-center justify-between">
                  <span>Direct WhatsApp Number:</span>
                  <span className="font-mono text-zinc-200">{profile.whatsappNumber}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Direct Email:</span>
                  <span className="text-zinc-200">{profile.email}</span>
                </div>
              </div>

            </div>

          </div>

          {/* Right Column: Contact Form */}
          <div className="lg:col-span-7">
            <div className="bg-zinc-950/90 border border-zinc-800 rounded-2xl p-6 sm:p-10 shadow-xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-40 h-40 bg-amber-500/5 rounded-full blur-2xl pointer-events-none" />

              <h3 className="text-xl font-bold text-white mb-2">
                Send a Direct Message
              </h3>
              <p className="text-zinc-400 text-sm mb-6">
                Fill in the details below to submit a message or forward your inquiry directly to WhatsApp.
              </p>

              {submitted ? (
                <div className="py-8 text-center space-y-4">
                  <div className="w-14 h-14 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 mx-auto flex items-center justify-center">
                    <CheckCircle2 className="w-7 h-7" />
                  </div>
                  <h4 className="text-xl font-bold text-white font-serif-luxury">
                    Thank You, {formData.name}!
                  </h4>
                  <p className="text-zinc-300 text-sm max-w-md mx-auto">
                    Your message has been recorded. For the fastest response, you can also send this note directly via WhatsApp right now.
                  </p>

                  <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
                    <button
                      onClick={openWhatsAppWithMessage}
                      className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-2.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-black font-semibold text-xs uppercase tracking-wider transition-colors"
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span>Send via WhatsApp Now</span>
                    </button>
                    <button
                      onClick={() => {
                        setSubmitted(false);
                        setFormData({ name: '', email: '', subject: 'Consulting Advisory', message: '' });
                      }}
                      className="w-full sm:w-auto px-5 py-2.5 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-white text-xs font-medium transition-colors"
                    >
                      Send Another Message
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label htmlFor="name" className="block text-xs font-medium text-zinc-300 mb-1.5 uppercase tracking-wider">
                        Your Name <span className="text-amber-400">*</span>
                      </label>
                      <input
                        id="name"
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="e.g. Rahul Sharma"
                        className="w-full px-4 py-3 bg-zinc-900 border border-zinc-800 rounded-xl text-white placeholder-zinc-500 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 text-sm transition-all"
                      />
                    </div>

                    <div>
                      <label htmlFor="email" className="block text-xs font-medium text-zinc-300 mb-1.5 uppercase tracking-wider">
                        Your Email <span className="text-amber-400">*</span>
                      </label>
                      <input
                        id="email"
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="e.g. rahul@example.com"
                        className="w-full px-4 py-3 bg-zinc-900 border border-zinc-800 rounded-xl text-white placeholder-zinc-500 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 text-sm transition-all"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="subject" className="block text-xs font-medium text-zinc-300 mb-1.5 uppercase tracking-wider">
                      Inquiry Type / Subject
                    </label>
                    <select
                      id="subject"
                      value={formData.subject}
                      onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                      className="w-full px-4 py-3 bg-zinc-900 border border-zinc-800 rounded-xl text-white focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 text-sm transition-all"
                    >
                      <option value="Strategic Business Advisory">Strategic Business Advisory</option>
                      <option value="Brand & Identity Architecture">Brand & Identity Architecture</option>
                      <option value="Client Engagement & Growth">Client Engagement & Growth</option>
                      <option value="General Conversation / Connect">General Conversation / Connect</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-xs font-medium text-zinc-300 mb-1.5 uppercase tracking-wider">
                      Message <span className="text-amber-400">*</span>
                    </label>
                    <textarea
                      id="message"
                      rows={4}
                      required
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      placeholder="Share your goals, project details, or what you'd like to collaborate on..."
                      className="w-full px-4 py-3 bg-zinc-900 border border-zinc-800 rounded-xl text-white placeholder-zinc-500 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 text-sm transition-all resize-y"
                    />
                  </div>

                  <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full sm:flex-1 inline-flex items-center justify-center gap-2 px-6 py-3.5 text-xs font-bold uppercase tracking-wider text-black bg-gradient-to-r from-amber-300 via-amber-400 to-amber-500 rounded-xl hover:from-amber-200 hover:to-amber-400 transition-all duration-300 shadow-md shadow-amber-500/20 disabled:opacity-50"
                    >
                      <Send className="w-4 h-4" />
                      <span>{isSubmitting ? 'Sending Message...' : 'Submit Message'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={openWhatsAppWithMessage}
                      disabled={!formData.name || !formData.message}
                      className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-3.5 text-xs font-semibold uppercase tracking-wider text-emerald-400 bg-zinc-900 border border-emerald-500/30 hover:bg-emerald-500/10 rounded-xl transition-all disabled:opacity-40 disabled:pointer-events-none"
                      title="Send straight to WhatsApp chat"
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span>Direct WhatsApp</span>
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
