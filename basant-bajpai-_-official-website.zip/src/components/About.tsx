import React from 'react';
import { Target, Compass, Trophy, Heart, Edit3, ArrowUpRight } from 'lucide-react';
import { ProfileData } from '../types';

interface AboutProps {
  profile: ProfileData;
  onOpenEditModal: () => void;
}

export const About: React.FC<AboutProps> = ({ profile, onOpenEditModal }) => {
  return (
    <section id="about" className="py-20 lg:py-28 relative border-b border-zinc-800/80 bg-[#09090b]">
      {/* Subtle background glow */}
      <div
        className="absolute bottom-10 left-10 w-96 h-96 bg-amber-500/5 rounded-full blur-[120px] pointer-events-none"
        aria-hidden="true"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <span className="text-xs font-semibold uppercase tracking-[0.2em] text-amber-400">
              Personal Profile
            </span>
            <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-bold text-white mt-2">
              About Basant Bajpai
            </h2>
          </div>
          <button
            onClick={onOpenEditModal}
            className="self-start md:self-auto inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold uppercase tracking-wider text-amber-300 hover:text-white bg-zinc-900 border border-amber-500/30 hover:border-amber-400 rounded-lg transition-all"
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>Customize My Information</span>
          </button>
        </div>

        {/* Narrative & Philosophy Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start mb-16">
          
          {/* Main Story Narrative */}
          <div className="lg:col-span-7 space-y-6">
            <h3 className="text-xl sm:text-2xl font-serif-luxury text-amber-200/90 font-medium leading-relaxed">
              "Creating a distinct identity requires clear vision, unyielding discipline, and strategic clarity."
            </h3>
            
            <p className="text-zinc-300 text-base sm:text-lg leading-relaxed font-light">
              {profile.aboutIntro}
            </p>

            <p className="text-zinc-400 text-sm sm:text-base leading-relaxed">
              Every venture starts with defining who you are and what you stand for. In modern consulting, the biggest differentiator is not superficial noise, but deep domain focus, transparent communication, and consistent follow-through.
            </p>

            <div className="pt-4 flex items-center gap-4">
              <a
                href={profile.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-sm font-semibold text-amber-400 hover:text-amber-300 underline underline-offset-4 group"
              >
                <span>Discuss a strategic opportunity</span>
                <ArrowUpRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </a>
            </div>
          </div>

          {/* Quick Credibility Summary Card */}
          <div className="lg:col-span-5 bg-zinc-900/60 border border-zinc-800 rounded-2xl p-6 sm:p-8 backdrop-blur-sm relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />
            <h4 className="text-base font-semibold text-white mb-6 uppercase tracking-wider text-xs text-amber-400">
              Identity Pillars
            </h4>

            <div className="space-y-4">
              <div className="pb-3 border-b border-zinc-800/80">
                <div className="text-xs text-zinc-400 uppercase tracking-wider">Professional Role</div>
                <div className="text-base font-medium text-white mt-1">Founder & Strategy Consultant</div>
              </div>

              <div className="pb-3 border-b border-zinc-800/80">
                <div className="text-xs text-zinc-400 uppercase tracking-wider">Direct Focus</div>
                <div className="text-base font-medium text-white mt-1">Identity Architecture & Strategic Growth</div>
              </div>

              <div className="pb-3 border-b border-zinc-800/80">
                <div className="text-xs text-zinc-400 uppercase tracking-wider">Location & Reach</div>
                <div className="text-base font-medium text-white mt-1">{profile.location} · Global Digital Advisory</div>
              </div>

              <div>
                <div className="text-xs text-zinc-400 uppercase tracking-wider">Primary Channel</div>
                <div className="text-base font-medium text-amber-300 mt-1">WhatsApp & Direct Consultation</div>
              </div>
            </div>
          </div>

        </div>

        {/* 4 Interactive Columns: Interests, Goals, Hobbies, Achievements */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          
          {/* Card 1: Interests */}
          <div className="bg-zinc-950/80 border border-zinc-800/90 hover:border-amber-400/30 rounded-2xl p-6 transition-all duration-300 hover:-translate-y-1 group">
            <div className="w-10 h-10 rounded-xl bg-amber-400/10 text-amber-400 flex items-center justify-center mb-5 group-hover:bg-amber-400/20 transition-colors">
              <Compass className="w-5 h-5" />
            </div>
            <h4 className="text-lg font-bold text-white mb-4">Core Interests</h4>
            <ul className="space-y-2.5 text-xs sm:text-sm text-zinc-300">
              {profile.interests.map((interest, idx) => (
                <li key={idx} className="flex items-start gap-2.5 leading-snug">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-1.5 shrink-0" />
                  <span>{interest}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Card 2: Goals */}
          <div className="bg-zinc-950/80 border border-zinc-800/90 hover:border-amber-400/30 rounded-2xl p-6 transition-all duration-300 hover:-translate-y-1 group">
            <div className="w-10 h-10 rounded-xl bg-amber-400/10 text-amber-400 flex items-center justify-center mb-5 group-hover:bg-amber-400/20 transition-colors">
              <Target className="w-5 h-5" />
            </div>
            <h4 className="text-lg font-bold text-white mb-4">Strategic Goals</h4>
            <ul className="space-y-2.5 text-xs sm:text-sm text-zinc-300">
              {profile.goals.map((goal, idx) => (
                <li key={idx} className="flex items-start gap-2.5 leading-snug">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-1.5 shrink-0" />
                  <span>{goal}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Card 3: Hobbies */}
          <div className="bg-zinc-950/80 border border-zinc-800/90 hover:border-amber-400/30 rounded-2xl p-6 transition-all duration-300 hover:-translate-y-1 group">
            <div className="w-10 h-10 rounded-xl bg-amber-400/10 text-amber-400 flex items-center justify-center mb-5 group-hover:bg-amber-400/20 transition-colors">
              <Heart className="w-5 h-5" />
            </div>
            <h4 className="text-lg font-bold text-white mb-4">Personal Hobbies</h4>
            <ul className="space-y-2.5 text-xs sm:text-sm text-zinc-300">
              {profile.hobbies.map((hobby, idx) => (
                <li key={idx} className="flex items-start gap-2.5 leading-snug">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-1.5 shrink-0" />
                  <span>{hobby}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Card 4: Achievements */}
          <div className="bg-zinc-950/80 border border-zinc-800/90 hover:border-amber-400/30 rounded-2xl p-6 transition-all duration-300 hover:-translate-y-1 group">
            <div className="w-10 h-10 rounded-xl bg-amber-400/10 text-amber-400 flex items-center justify-center mb-5 group-hover:bg-amber-400/20 transition-colors">
              <Trophy className="w-5 h-5" />
            </div>
            <h4 className="text-lg font-bold text-white mb-4">Milestones</h4>
            <ul className="space-y-2.5 text-xs sm:text-sm text-zinc-300">
              {profile.achievements.map((achievement, idx) => (
                <li key={idx} className="flex items-start gap-2.5 leading-snug">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-1.5 shrink-0" />
                  <span>{achievement}</span>
                </li>
              ))}
            </ul>
          </div>

        </div>

        {/* Editable Notice Strip */}
        <div className="mt-10 p-4 rounded-xl bg-zinc-900/40 border border-zinc-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3 text-xs text-zinc-400">
            <span className="w-2 h-2 rounded-full bg-amber-400" />
            <span>Customize this section at any time with your latest milestones, goals, or hobbies.</span>
          </div>
          <button
            onClick={onOpenEditModal}
            className="text-xs font-semibold text-amber-400 hover:text-amber-300 underline underline-offset-2 whitespace-nowrap"
          >
            Edit Information Now →
          </button>
        </div>

      </div>
    </section>
  );
};
