import React from 'react';
import { Instagram, MessageCircle, ArrowUp } from 'lucide-react';
import { ProfileData } from '../types';

interface FooterProps {
  profile: ProfileData;
}

export const Footer: React.FC<FooterProps> = ({ profile }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="w-full bg-[#050507] border-t border-zinc-800/80 py-12 text-zinc-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          
          {/* Brand & Exact Copyright notice */}
          <div className="text-center md:text-left">
            <div className="text-white font-serif-luxury font-bold tracking-wider text-base mb-1">
              BASANT BAJPAI
            </div>
            <p className="text-xs text-zinc-500">
              © 2026 Basant Bajpai. All Rights Reserved.
            </p>
          </div>

          {/* Social Icons for Instagram & WhatsApp */}
          <div className="flex items-center gap-4">
            <a
              href={profile.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-10 h-10 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-300 hover:text-pink-400 hover:border-pink-500/50 hover:bg-zinc-850 transition-all"
              aria-label="Instagram Profile"
              title="Instagram: basant_.bajpai"
            >
              <Instagram className="w-5 h-5" />
            </a>

            <a
              href={profile.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-10 h-10 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-300 hover:text-emerald-400 hover:border-emerald-500/50 hover:bg-zinc-850 transition-all"
              aria-label="Chat on WhatsApp"
              title="WhatsApp: +91 6232322853"
            >
              <MessageCircle className="w-5 h-5" />
            </a>

            {/* Back to top button */}
            <button
              onClick={scrollToTop}
              className="w-10 h-10 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-400 hover:text-amber-400 hover:border-amber-400/40 transition-all ml-2"
              aria-label="Back to top"
              title="Scroll to top"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>

        </div>
      </div>
    </footer>
  );
};
