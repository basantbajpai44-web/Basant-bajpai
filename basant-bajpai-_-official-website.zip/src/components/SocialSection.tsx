import React, { useState } from 'react';
import { Instagram, MessageCircle, Mail, Copy, Check, ExternalLink, ArrowRight } from 'lucide-react';
import { ProfileData } from '../types';

interface SocialSectionProps {
  profile: ProfileData;
}

export const SocialSection: React.FC<SocialSectionProps> = ({ profile }) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  return (
    <section id="social" className="py-20 lg:py-28 relative border-b border-zinc-800/80 bg-[#0c0c0e]">
      {/* Background ambient lighting */}
      <div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-amber-500/5 rounded-full blur-[140px] pointer-events-none"
        aria-hidden="true"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-xs font-semibold uppercase tracking-[0.2em] text-amber-400">
            Connect & Follow
          </span>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-bold text-white mt-2 mb-4">
            Official Social Channels
          </h2>
          <p className="text-zinc-400 text-base">
            Stay connected with my latest updates, daily insights, and direct professional dialogues across Instagram and WhatsApp.
          </p>
        </div>

        {/* Social Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          
          {/* Card 1: Instagram (Prominent) */}
          <div className="bg-gradient-to-b from-zinc-900 to-zinc-950 border border-zinc-800 hover:border-pink-500/40 rounded-2xl p-8 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-pink-950/20 group flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-6">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500 via-pink-600 to-purple-600 p-[2px]">
                  <div className="w-full h-full bg-zinc-950 rounded-[14px] flex items-center justify-center text-pink-400 group-hover:scale-105 transition-transform">
                    <Instagram className="w-7 h-7" />
                  </div>
                </div>
                <button
                  onClick={() => handleCopy(profile.instagramHandle, 'ig')}
                  className="p-2 text-zinc-500 hover:text-white rounded-lg hover:bg-zinc-800 transition-colors"
                  title="Copy Instagram handle"
                >
                  {copiedKey === 'ig' ? (
                    <Check className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </button>
              </div>

              <div className="text-xs font-semibold uppercase tracking-wider text-pink-400 mb-1">
                Instagram Profile
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">
                {profile.instagramHandle}
              </h3>
              <p className="text-zinc-400 text-sm leading-relaxed mb-6 font-light">
                Follow my personal journey, behind-the-scenes consulting milestones, and lifestyle reflections.
              </p>
            </div>

            <a
              href={profile.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 w-full px-5 py-3 rounded-xl bg-zinc-900 border border-pink-500/30 text-white font-medium text-sm hover:bg-gradient-to-r hover:from-pink-600 hover:to-purple-600 hover:border-transparent transition-all duration-300 shadow-sm"
            >
              <span>Follow on Instagram</span>
              <ExternalLink className="w-4 h-4" />
            </a>
          </div>

          {/* Card 2: WhatsApp (Direct Communication) */}
          <div className="bg-gradient-to-b from-zinc-900 to-zinc-950 border border-zinc-800 hover:border-emerald-500/40 rounded-2xl p-8 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-emerald-950/20 group flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-6">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-emerald-600 via-teal-500 to-emerald-400 p-[2px]">
                  <div className="w-full h-full bg-zinc-950 rounded-[14px] flex items-center justify-center text-emerald-400 group-hover:scale-105 transition-transform">
                    <MessageCircle className="w-7 h-7" />
                  </div>
                </div>
                <button
                  onClick={() => handleCopy(profile.whatsappNumber, 'wa')}
                  className="p-2 text-zinc-500 hover:text-white rounded-lg hover:bg-zinc-800 transition-colors"
                  title="Copy WhatsApp number"
                >
                  {copiedKey === 'wa' ? (
                    <Check className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </button>
              </div>

              <div className="text-xs font-semibold uppercase tracking-wider text-emerald-400 mb-1">
                Direct WhatsApp
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">
                {profile.whatsappNumber}
              </h3>
              <p className="text-zinc-400 text-sm leading-relaxed mb-6 font-light">
                Direct chat link for consulting inquiries, business collaborations, or quick conversational greetings.
              </p>
            </div>

            <a
              href={profile.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 w-full px-5 py-3 rounded-xl bg-zinc-900 border border-emerald-500/30 text-white font-medium text-sm hover:bg-gradient-to-r hover:from-emerald-600 hover:to-teal-600 hover:border-transparent transition-all duration-300 shadow-sm"
            >
              <span>Message on WhatsApp</span>
              <ArrowRight className="w-4 h-4" />
            </a>
          </div>

          {/* Card 3: Email Consultation Inquiry */}
          <div className="bg-gradient-to-b from-zinc-900 to-zinc-950 border border-zinc-800 hover:border-amber-400/40 rounded-2xl p-8 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-amber-950/20 group flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-6">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500 via-amber-400 to-yellow-300 p-[2px]">
                  <div className="w-full h-full bg-zinc-950 rounded-[14px] flex items-center justify-center text-amber-400 group-hover:scale-105 transition-transform">
                    <Mail className="w-7 h-7" />
                  </div>
                </div>
                <button
                  onClick={() => handleCopy(profile.email, 'email')}
                  className="p-2 text-zinc-500 hover:text-white rounded-lg hover:bg-zinc-800 transition-colors"
                  title="Copy email address"
                >
                  {copiedKey === 'email' ? (
                    <Check className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </button>
              </div>

              <div className="text-xs font-semibold uppercase tracking-wider text-amber-400 mb-1">
                Official Email
              </div>
              <h3 className="text-xl font-bold text-white mb-2 truncate">
                {profile.email}
              </h3>
              <p className="text-zinc-400 text-sm leading-relaxed mb-6 font-light">
                For detailed project briefs, formal advisory contracts, and high-level enterprise proposals.
              </p>
            </div>

            <a
              href={`mailto:${profile.email}?subject=${encodeURIComponent('Strategic Consulting Inquiry')}`}
              className="inline-flex items-center justify-center gap-2 w-full px-5 py-3 rounded-xl bg-zinc-900 border border-amber-400/30 text-white font-medium text-sm hover:bg-gradient-to-r hover:from-amber-400 hover:to-amber-500 hover:text-black hover:border-transparent transition-all duration-300 shadow-sm"
            >
              <span>Send Email Brief</span>
              <ExternalLink className="w-4 h-4" />
            </a>
          </div>

        </div>

      </div>
    </section>
  );
};
