import React, { useState } from 'react';
import { ExternalLink, X, ArrowUpRight, CheckCircle2 } from 'lucide-react';
import { PortfolioItem } from '../types';

interface PortfolioProps {
  projects: PortfolioItem[];
  whatsappUrl: string;
}

export const Portfolio: React.FC<PortfolioProps> = ({ projects, whatsappUrl }) => {
  const [activeFilter, setActiveFilter] = useState<'All' | 'Strategy' | 'Branding' | 'Growth'>('All');
  const [selectedProject, setSelectedProject] = useState<PortfolioItem | null>(null);

  const filteredProjects = activeFilter === 'All'
    ? projects
    : projects.filter((p) => p.category === activeFilter);

  return (
    <section id="portfolio" className="py-20 lg:py-28 relative border-b border-zinc-800/80 bg-[#09090b]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header & Filter Controls */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div>
            <span className="text-xs font-semibold uppercase tracking-[0.2em] text-amber-400">
              Selected Engagements
            </span>
            <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-bold text-white mt-2">
              Consulting Portfolio
            </h2>
          </div>

          {/* Interactive filter segmented control */}
          <div className="flex items-center gap-1.5 p-1 bg-zinc-900 border border-zinc-800 rounded-xl self-start md:self-auto">
            {(['All', 'Strategy', 'Branding', 'Growth'] as const).map((filter) => (
              <button
                key={filter}
                onClick={() => setActiveFilter(filter)}
                className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-all duration-200 whitespace-nowrap shrink-0 ${
                  activeFilter === filter
                    ? 'bg-amber-400 text-black font-semibold shadow-sm'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                {filter === 'All' ? 'All Engagements' : filter}
              </button>
            ))}
          </div>
        </div>

        {/* Portfolio Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              onClick={() => setSelectedProject(project)}
              className="group cursor-pointer bg-zinc-950/80 border border-zinc-800/90 hover:border-amber-400/50 rounded-2xl overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl hover:shadow-black flex flex-col"
            >
              {/* Media Container with measured scrim overlay */}
              <div className="relative h-56 sm:h-64 w-full overflow-hidden bg-zinc-900">
                <img
                  src={project.imageUrl}
                  alt={project.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  onError={(e) => {
                    const target = e.currentTarget;
                    target.style.display = 'none';
                    if (target.parentElement) {
                      target.parentElement.innerHTML = `
                        <div class="w-full h-full flex items-center justify-center bg-zinc-900 text-zinc-500 font-serif-luxury text-2xl">
                          ${project.title}
                        </div>
                      `;
                    }
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/40 to-transparent" />
                
                {/* Category & Year Tag (Zero-pill discipline: quiet inline styling) */}
                <div className="absolute top-4 left-4 flex items-center gap-2 text-xs font-medium text-amber-300 bg-black/70 backdrop-blur-md px-3 py-1 rounded-md border border-amber-400/30">
                  <span>{project.category}</span>
                  <span aria-hidden="true">·</span>
                  <span>{project.year}</span>
                </div>

                <div className="absolute top-4 right-4 w-8 h-8 rounded-full bg-black/60 border border-zinc-700 flex items-center justify-center text-zinc-300 group-hover:bg-amber-400 group-hover:text-black group-hover:border-amber-400 transition-colors">
                  <ArrowUpRight className="w-4 h-4" />
                </div>
              </div>

              {/* Text content */}
              <div className="p-6 flex-1 flex flex-col justify-between">
                <div>
                  <div className="text-xs text-zinc-400 mb-1">{project.clientType}</div>
                  <h3 className="text-lg font-bold text-white group-hover:text-amber-300 transition-colors mb-3">
                    {project.title}
                  </h3>
                  <p className="text-zinc-300 text-xs sm:text-sm line-clamp-2 leading-relaxed">
                    {project.summary}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-zinc-900 flex items-center justify-between text-xs text-amber-400 font-medium">
                  <span>Read Case Study Details</span>
                  <span className="group-hover:translate-x-1 transition-transform">→</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Modal Detail View */}
        {selectedProject && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
            <div className="bg-zinc-950 border border-zinc-700/80 rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl relative p-6 sm:p-8">
              
              {/* Close Button */}
              <button
                onClick={() => setSelectedProject(null)}
                className="absolute top-5 right-5 p-2 rounded-lg bg-zinc-900 text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
                aria-label="Close dialog"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 uppercase tracking-widest mb-2">
                <span>{selectedProject.category}</span>
                <span>·</span>
                <span>{selectedProject.year}</span>
                <span>·</span>
                <span>{selectedProject.clientType}</span>
              </div>

              <h3 className="text-2xl font-serif-luxury font-bold text-white mb-4">
                {selectedProject.title}
              </h3>

              <div className="relative h-60 rounded-xl overflow-hidden mb-6 bg-zinc-900 border border-zinc-800">
                <img
                  src={selectedProject.imageUrl}
                  alt={selectedProject.title}
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="space-y-5 text-sm">
                <div>
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-amber-400 mb-1">
                    The Challenge
                  </h4>
                  <p className="text-zinc-300 leading-relaxed">
                    {selectedProject.challenge}
                  </p>
                </div>

                <div>
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-amber-400 mb-1">
                    Strategic Solution
                  </h4>
                  <p className="text-zinc-300 leading-relaxed">
                    {selectedProject.solution}
                  </p>
                </div>

                <div>
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-amber-400 mb-2">
                    Key Outcomes & Impact
                  </h4>
                  <ul className="space-y-2">
                    {selectedProject.impact.map((item, i) => (
                      <li key={i} className="flex items-start gap-2 text-zinc-200 text-xs sm:text-sm">
                        <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="mt-8 pt-6 border-t border-zinc-800 flex flex-col sm:flex-row items-center justify-between gap-4">
                <span className="text-xs text-zinc-400">
                  Interested in similar strategic outcomes?
                </span>
                <a
                  href={`${whatsappUrl}?text=${encodeURIComponent(`Hi Basant, I was reviewing your portfolio project "${selectedProject.title}" and would like to discuss a similar advisory project.`)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg bg-gradient-to-r from-amber-400 to-amber-500 text-black font-semibold text-xs uppercase tracking-wider hover:from-amber-300 hover:to-amber-400 transition-colors"
                >
                  <span>Discuss On WhatsApp</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>

            </div>
          </div>
        )}

      </div>
    </section>
  );
};
