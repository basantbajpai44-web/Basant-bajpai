import React from 'react';
import { Briefcase, Crown, TrendingUp, Layers, Check, MessageSquare } from 'lucide-react';
import { ConsultingService } from '../types';

interface ServicesProps {
  services: ConsultingService[];
  whatsappUrl: string;
}

export const Services: React.FC<ServicesProps> = ({ services, whatsappUrl }) => {
  const getIcon = (type: string) => {
    switch (type) {
      case 'strategy':
        return <Briefcase className="w-5 h-5 text-amber-400" />;
      case 'brand':
        return <Crown className="w-5 h-5 text-amber-400" />;
      case 'growth':
        return <TrendingUp className="w-5 h-5 text-amber-400" />;
      case 'operations':
      default:
        return <Layers className="w-5 h-5 text-amber-400" />;
    }
  };

  return (
    <section id="services" className="py-20 lg:py-28 relative border-b border-zinc-800/80 bg-[#0c0c0e]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-semibold uppercase tracking-[0.2em] text-amber-400">
            Consulting Practice
          </span>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-bold text-white mt-2 mb-4">
            Services & Strategic Capabilities
          </h2>
          <p className="text-zinc-400 text-base sm:text-lg">
            High-leverage advisory tailored to founders, modern business leaders, and ambitious professionals seeking authoritative brand positioning and operational clarity.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {services.map((service, index) => (
            <div
              key={service.id}
              className="bg-zinc-950/70 border border-zinc-800/80 hover:border-amber-400/40 rounded-2xl p-8 transition-all duration-300 hover:shadow-xl hover:shadow-black/60 group relative flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-6">
                  <div className="w-12 h-12 rounded-xl bg-amber-400/10 border border-amber-400/20 flex items-center justify-center group-hover:scale-110 group-hover:bg-amber-400/20 transition-all duration-300">
                    {getIcon(service.icon)}
                  </div>
                  <span className="text-xs font-medium text-zinc-500 font-mono">
                    0{index + 1}
                  </span>
                </div>

                <h3 className="text-xl font-bold text-white mb-2 group-hover:text-amber-300 transition-colors">
                  {service.title}
                </h3>
                <p className="text-amber-300/80 text-sm font-medium mb-4">
                  {service.shortDesc}
                </p>
                <p className="text-zinc-400 text-sm leading-relaxed mb-6 font-light">
                  {service.fullDesc}
                </p>

                <div className="space-y-2.5 pt-4 border-t border-zinc-900">
                  <div className="text-xs font-semibold uppercase tracking-wider text-zinc-500 mb-2">
                    Key Deliverables
                  </div>
                  {service.features.map((feature, fIndex) => (
                    <div key={fIndex} className="flex items-start gap-2.5 text-xs sm:text-sm text-zinc-300">
                      <Check className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-8 pt-6 border-t border-zinc-800/60 flex items-center justify-between">
                <span className="text-xs text-zinc-400">Custom Engagement</span>
                <a
                  href={`${whatsappUrl}?text=${encodeURIComponent(`Hi Basant, I would like to consult with you regarding ${service.title}.`)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-400 hover:text-amber-300 transition-colors"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>Inquire on WhatsApp</span>
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Consulting Process strip */}
        <div className="mt-16 bg-gradient-to-r from-zinc-900/90 via-zinc-950 to-zinc-900/90 border border-zinc-800 rounded-2xl p-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center md:text-left">
            <div>
              <div className="text-amber-400 font-mono text-sm font-semibold mb-1">Step 01</div>
              <h4 className="text-white font-bold text-base mb-1">Direct Discovery</h4>
              <p className="text-zinc-400 text-xs leading-relaxed">
                A focused consultation via WhatsApp or video call to identify core friction points and objectives.
              </p>
            </div>
            <div>
              <div className="text-amber-400 font-mono text-sm font-semibold mb-1">Step 02</div>
              <h4 className="text-white font-bold text-base mb-1">Strategic Framework</h4>
              <p className="text-zinc-400 text-xs leading-relaxed">
                Co-architecting an actionable roadmap, positioning narrative, or operational cadence.
              </p>
            </div>
            <div>
              <div className="text-amber-400 font-mono text-sm font-semibold mb-1">Step 03</div>
              <h4 className="text-white font-bold text-base mb-1">Disciplined Execution</h4>
              <p className="text-zinc-400 text-xs leading-relaxed">
                Rigorous follow-through, measuring real outcomes, and refining market identity.
              </p>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
