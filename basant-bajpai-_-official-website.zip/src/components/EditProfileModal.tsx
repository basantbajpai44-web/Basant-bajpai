import React, { useState } from 'react';
import { X, Check, Plus, Trash2, RotateCcw } from 'lucide-react';
import { ProfileData } from '../types';

interface EditProfileModalProps {
  profile: ProfileData;
  onSave: (updatedProfile: ProfileData) => void;
  onReset: () => void;
  onClose: () => void;
}

export const EditProfileModal: React.FC<EditProfileModalProps> = ({
  profile,
  onSave,
  onReset,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'general' | 'lists' | 'social'>('general');
  const [formData, setFormData] = useState<ProfileData>({ ...profile });

  // List item input helpers
  const [newInterest, setNewInterest] = useState('');
  const [newGoal, setNewGoal] = useState('');
  const [newHobby, setNewHobby] = useState('');
  const [newAchievement, setNewAchievement] = useState('');

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
    onClose();
  };

  const addItem = (key: 'interests' | 'goals' | 'hobbies' | 'achievements', value: string, setter: (val: string) => void) => {
    if (!value.trim()) return;
    setFormData({
      ...formData,
      [key]: [...formData[key], value.trim()],
    });
    setter('');
  };

  const removeItem = (key: 'interests' | 'goals' | 'hobbies' | 'achievements', index: number) => {
    setFormData({
      ...formData,
      [key]: formData[key].filter((_, i) => i !== index),
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-zinc-950 border border-zinc-800 rounded-2xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl relative">
        
        {/* Header */}
        <div className="px-6 py-5 border-b border-zinc-800 flex items-center justify-between">
          <div>
            <h3 className="text-xl font-bold font-serif-luxury text-white">
              Customize Website Information
            </h3>
            <p className="text-xs text-zinc-400 mt-0.5">
              Edit your name, tagline, introduction, goals, hobbies, and social links anytime.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg bg-zinc-900 text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-zinc-800 bg-zinc-900/50 px-6 gap-6 text-xs font-semibold">
          <button
            type="button"
            onClick={() => setActiveTab('general')}
            className={`py-3 relative transition-colors ${
              activeTab === 'general' ? 'text-amber-400' : 'text-zinc-400 hover:text-white'
            }`}
          >
            General & Bio
            {activeTab === 'general' && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-400" />
            )}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('lists')}
            className={`py-3 relative transition-colors ${
              activeTab === 'lists' ? 'text-amber-400' : 'text-zinc-400 hover:text-white'
            }`}
          >
            Interests, Goals & Hobbies
            {activeTab === 'lists' && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-400" />
            )}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('social')}
            className={`py-3 relative transition-colors ${
              activeTab === 'social' ? 'text-amber-400' : 'text-zinc-400 hover:text-white'
            }`}
          >
            Social & Contact Links
            {activeTab === 'social' && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-400" />
            )}
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSave} className="flex-1 overflow-y-auto p-6 space-y-6">
          
          {/* TAB 1: General & Bio */}
          {activeTab === 'general' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-zinc-300 uppercase tracking-wider mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-4 py-2.5 bg-zinc-900 border border-zinc-800 rounded-xl text-white text-sm focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-zinc-300 uppercase tracking-wider mb-1">
                  Tagline
                </label>
                <input
                  type="text"
                  value={formData.tagline}
                  onChange={(e) => setFormData({ ...formData, tagline: e.target.value })}
                  className="w-full px-4 py-2.5 bg-zinc-900 border border-zinc-800 rounded-xl text-white text-sm focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-zinc-300 uppercase tracking-wider mb-1">
                  Hero Short Introduction
                </label>
                <textarea
                  rows={3}
                  value={formData.heroIntro}
                  onChange={(e) => setFormData({ ...formData, heroIntro: e.target.value })}
                  className="w-full px-4 py-2.5 bg-zinc-900 border border-zinc-800 rounded-xl text-white text-sm focus:outline-none focus:border-amber-400 resize-y"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-zinc-300 uppercase tracking-wider mb-1">
                  About Me Detailed Narrative
                </label>
                <textarea
                  rows={4}
                  value={formData.aboutIntro}
                  onChange={(e) => setFormData({ ...formData, aboutIntro: e.target.value })}
                  className="w-full px-4 py-2.5 bg-zinc-900 border border-zinc-800 rounded-xl text-white text-sm focus:outline-none focus:border-amber-400 resize-y"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-zinc-300 uppercase tracking-wider mb-1">
                  Location / Base
                </label>
                <input
                  type="text"
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  className="w-full px-4 py-2.5 bg-zinc-900 border border-zinc-800 rounded-xl text-white text-sm focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>
          )}

          {/* TAB 2: Lists */}
          {activeTab === 'lists' && (
            <div className="space-y-6">
              
              {/* Interests */}
              <div>
                <label className="block text-xs font-semibold text-amber-400 uppercase tracking-wider mb-2">
                  Interests
                </label>
                <div className="space-y-2 mb-2">
                  {formData.interests.map((item, idx) => (
                    <div key={idx} className="flex items-center justify-between p-2.5 bg-zinc-900 rounded-lg border border-zinc-800 text-xs text-zinc-200">
                      <span>{item}</span>
                      <button
                        type="button"
                        onClick={() => removeItem('interests', idx)}
                        className="text-zinc-500 hover:text-rose-400 p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newInterest}
                    onChange={(e) => setNewInterest(e.target.value)}
                    placeholder="Add an interest..."
                    className="flex-1 px-3 py-1.5 bg-zinc-900 border border-zinc-800 rounded-lg text-xs text-white"
                  />
                  <button
                    type="button"
                    onClick={() => addItem('interests', newInterest, setNewInterest)}
                    className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-white rounded-lg text-xs flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add</span>
                  </button>
                </div>
              </div>

              {/* Goals */}
              <div>
                <label className="block text-xs font-semibold text-amber-400 uppercase tracking-wider mb-2">
                  Goals
                </label>
                <div className="space-y-2 mb-2">
                  {formData.goals.map((item, idx) => (
                    <div key={idx} className="flex items-center justify-between p-2.5 bg-zinc-900 rounded-lg border border-zinc-800 text-xs text-zinc-200">
                      <span>{item}</span>
                      <button
                        type="button"
                        onClick={() => removeItem('goals', idx)}
                        className="text-zinc-500 hover:text-rose-400 p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newGoal}
                    onChange={(e) => setNewGoal(e.target.value)}
                    placeholder="Add a goal..."
                    className="flex-1 px-3 py-1.5 bg-zinc-900 border border-zinc-800 rounded-lg text-xs text-white"
                  />
                  <button
                    type="button"
                    onClick={() => addItem('goals', newGoal, setNewGoal)}
                    className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-white rounded-lg text-xs flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add</span>
                  </button>
                </div>
              </div>

              {/* Hobbies */}
              <div>
                <label className="block text-xs font-semibold text-amber-400 uppercase tracking-wider mb-2">
                  Hobbies
                </label>
                <div className="space-y-2 mb-2">
                  {formData.hobbies.map((item, idx) => (
                    <div key={idx} className="flex items-center justify-between p-2.5 bg-zinc-900 rounded-lg border border-zinc-800 text-xs text-zinc-200">
                      <span>{item}</span>
                      <button
                        type="button"
                        onClick={() => removeItem('hobbies', idx)}
                        className="text-zinc-500 hover:text-rose-400 p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newHobby}
                    onChange={(e) => setNewHobby(e.target.value)}
                    placeholder="Add a hobby..."
                    className="flex-1 px-3 py-1.5 bg-zinc-900 border border-zinc-800 rounded-lg text-xs text-white"
                  />
                  <button
                    type="button"
                    onClick={() => addItem('hobbies', newHobby, setNewHobby)}
                    className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-white rounded-lg text-xs flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add</span>
                  </button>
                </div>
              </div>

              {/* Achievements */}
              <div>
                <label className="block text-xs font-semibold text-amber-400 uppercase tracking-wider mb-2">
                  Achievements / Milestones
                </label>
                <div className="space-y-2 mb-2">
                  {formData.achievements.map((item, idx) => (
                    <div key={idx} className="flex items-center justify-between p-2.5 bg-zinc-900 rounded-lg border border-zinc-800 text-xs text-zinc-200">
                      <span>{item}</span>
                      <button
                        type="button"
                        onClick={() => removeItem('achievements', idx)}
                        className="text-zinc-500 hover:text-rose-400 p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newAchievement}
                    onChange={(e) => setNewAchievement(e.target.value)}
                    placeholder="Add an achievement..."
                    className="flex-1 px-3 py-1.5 bg-zinc-900 border border-zinc-800 rounded-lg text-xs text-white"
                  />
                  <button
                    type="button"
                    onClick={() => addItem('achievements', newAchievement, setNewAchievement)}
                    className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-white rounded-lg text-xs flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add</span>
                  </button>
                </div>
              </div>

            </div>
          )}

          {/* TAB 3: Social & Contact Links */}
          {activeTab === 'social' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-zinc-300 uppercase tracking-wider mb-1">
                  WhatsApp Direct URL (wa.me)
                </label>
                <input
                  type="text"
                  value={formData.whatsappUrl}
                  onChange={(e) => setFormData({ ...formData, whatsappUrl: e.target.value })}
                  placeholder="https://wa.me/916232322853"
                  className="w-full px-4 py-2.5 bg-zinc-900 border border-zinc-800 rounded-xl text-white text-sm focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-zinc-300 uppercase tracking-wider mb-1">
                  WhatsApp Display Number
                </label>
                <input
                  type="text"
                  value={formData.whatsappNumber}
                  onChange={(e) => setFormData({ ...formData, whatsappNumber: e.target.value })}
                  placeholder="+91 6232322853"
                  className="w-full px-4 py-2.5 bg-zinc-900 border border-zinc-800 rounded-xl text-white text-sm focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-zinc-300 uppercase tracking-wider mb-1">
                  Instagram Profile URL
                </label>
                <input
                  type="text"
                  value={formData.instagramUrl}
                  onChange={(e) => setFormData({ ...formData, instagramUrl: e.target.value })}
                  placeholder="https://www.instagram.com/basant_.bajpai?..."
                  className="w-full px-4 py-2.5 bg-zinc-900 border border-zinc-800 rounded-xl text-white text-sm focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-zinc-300 uppercase tracking-wider mb-1">
                  Instagram Display Handle
                </label>
                <input
                  type="text"
                  value={formData.instagramHandle}
                  onChange={(e) => setFormData({ ...formData, instagramHandle: e.target.value })}
                  placeholder="@basant_.bajpai"
                  className="w-full px-4 py-2.5 bg-zinc-900 border border-zinc-800 rounded-xl text-white text-sm focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-zinc-300 uppercase tracking-wider mb-1">
                  Official Email Address
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="basantbajpai44@gmail.com"
                  className="w-full px-4 py-2.5 bg-zinc-900 border border-zinc-800 rounded-xl text-white text-sm focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>
          )}

          {/* Modal Footer Controls */}
          <div className="pt-4 border-t border-zinc-800 flex items-center justify-between gap-3">
            <button
              type="button"
              onClick={() => {
                if (window.confirm('Reset all details to original default values?')) {
                  onReset();
                  onClose();
                }
              }}
              className="inline-flex items-center gap-1.5 text-xs text-zinc-400 hover:text-amber-400 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Defaults</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-medium text-zinc-300 hover:text-white bg-zinc-900 hover:bg-zinc-800 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-bold uppercase tracking-wider text-black bg-gradient-to-r from-amber-300 to-amber-500 rounded-lg hover:from-amber-200 hover:to-amber-400 transition-colors"
              >
                <Check className="w-3.5 h-3.5" />
                <span>Save Changes</span>
              </button>
            </div>
          </div>

        </form>
      </div>
    </div>
  );
};
